package com.medicare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicareCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicareCrudApplication.class, args);
	}

}
